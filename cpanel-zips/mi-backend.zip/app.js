// cPanel Node.js entry — loads the self-contained server bundle.
require('./server.cjs');
