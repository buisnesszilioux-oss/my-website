M.I. Engineering Works — Backend (cPanel Node.js App)

UPLOAD CONTENTS to: /home/<your-user>/mi-backend/  (or any folder)

cPanel → "Setup Node.js App":
  Application root      : mi-backend
  Application URL       : api.miengineeringworks.in   (or a sub-path)
  Application startup   : app.js
  Node version          : 18 or higher

Required Environment Variables (set in cPanel Node app settings):
  DATABASE_URL          = postgresql://neondb_owner:...@ep-shy-shadow-am3cyaj3.../neondb?sslmode=require
  JWT_SECRET            = -4hFGHwDWUtVIB7ZoBIJIRxTOzcxFnW3P5WKjG3XmVmcGT6edqV0ESUyioa5OyBd
  ADMIN_USERNAME        = miengineering@gmail.com
  ADMIN_PASSWORD        = 6392061892
  GOOGLE_CLIENT_ID      = 374744007598-plgqj6s9ds83v5aij2ehtm60ad2k86er.apps.googleusercontent.com
  NODE_ENV              = production

Then click "Run NPM Install" (NOT required — bundle is self-contained), then "Start App".

The bundle is self-contained — no npm install needed.
